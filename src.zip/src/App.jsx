/* App.jsx - protótipo completo */
// Código do protótipo que já criei anteriormente em React
